# LLM Navigation Assistant - Complete Integration Guide

## Overview

This guide provides step-by-step instructions for integrating the LLM-powered navigation assistant into your existing Catch-Up app. The solution follows your established AI orchestrator pattern and extends your current OpenAI integration.

## Architecture Summary

The navigation assistant consists of:

1. **Navigation Orchestrator Service** - Backend LLM service that processes navigation queries
2. **Enhanced Navigation Assistant UI** - Context-aware chat interface
3. **Guided Tour System** - Step-by-step feature walkthroughs  
4. **Smart Suggestion Engine** - Proactive AI-powered recommendations
5. **Intelligent Onboarding** - Adaptive user onboarding system
6. **Navigation Context Provider** - App state tracking and context awareness

## Prerequisites

- Existing Catch-Up app with OpenAI integration
- Node.js backend with Express and TypeScript
- React frontend with TypeScript
- Existing UI component library (Radix UI + Tailwind CSS)

## Step 1: Backend Integration

### 1.1 Add Navigation Orchestrator Service

Copy the `navigation_orchestrator_service.ts` file to your server directory:

```bash
cp navigation_orchestrator_service.ts server/navigationOrchestratorService.ts
```

### 1.2 Extend OpenAI Integration

Update your existing `server/openai.ts` file to include navigation assistant type:

```typescript
// Add to your existing AssistantType
export type AssistantType = 'general' | 'scheduling' | 'settings' | 'autoresponse' | 'navigation';

// Add to your API_KEY_MAP
const API_KEY_MAP: Record<AssistantType, string> = {
  'general': 'OPENAI_API_KEY',
  'scheduling': 'OPENAI_SCHEDULING_KEY', 
  'settings': 'OPENAI_SETTINGS_KEY',
  'autoresponse': 'OPENAI_AUTORESPONSE_KEY',
  'navigation': 'OPENAI_NAVIGATION_KEY' // Can use same key as general
};
```

### 1.3 Add API Routes

Add the navigation API routes to your existing `server/routes.ts` file:

```typescript
// Import the navigation service
import { 
  processNavigationCommand, 
  generateNavigationSuggestions, 
  analyzeNavigationIntent 
} from './navigationOrchestratorService';

// Add these routes to your existing routes
```

Then copy the route handlers from `navigation_api_routes.ts` into your routes file.

### 1.4 Extend Database Schema

Add navigation-specific fields to your existing user preferences schema:

```sql
-- Add to your existing user preferences table
ALTER TABLE user_preferences ADD COLUMN completed_tours TEXT[];
ALTER TABLE user_preferences ADD COLUMN preferred_tour_speed VARCHAR(10) DEFAULT 'normal';
ALTER TABLE user_preferences ADD COLUMN show_hints BOOLEAN DEFAULT true;
ALTER TABLE user_preferences ADD COLUMN auto_suggestions BOOLEAN DEFAULT true;

-- Create onboarding progress table
CREATE TABLE onboarding_progress (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  completed_steps TEXT[],
  current_flow VARCHAR(50),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

## Step 2: Frontend Integration

### 2.1 Add Context Provider

Copy the navigation context files to your client source:

```bash
cp NavigationContext.tsx client/src/components/NavigationContext.tsx
```

### 2.2 Wrap Your App with Navigation Provider

Update your main `App.tsx` to include the navigation provider:

```typescript
import { NavigationProvider } from '@/components/NavigationContext';

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Toaster />
      <TooltipProvider>
        <ThemeProvider>
          <UserProvider>
            <AppSettingsProvider>
              <NavigationProvider userId="current-user-id">
                {/* Your existing app content */}
                <Router />
                
                {/* Add navigation components */}
                <EnhancedNavigationAssistant />
                <GuidedTour />
                <SmartSuggestionEngine userId="current-user-id" />
                <IntelligentOnboarding 
                  userId="current-user-id"
                  isVisible={showOnboarding}
                  onComplete={() => setShowOnboarding(false)}
                  onSkip={() => setShowOnboarding(false)}
                />
              </NavigationProvider>
            </AppSettingsProvider>
          </UserProvider>
        </ThemeProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
```

### 2.3 Add Navigation Components

Copy all the React component files to your components directory:

```bash
cp EnhancedNavigationAssistant.tsx client/src/components/
cp GuidedTour.tsx client/src/components/
cp SmartSuggestionEngine.tsx client/src/components/
cp IntelligentOnboarding.tsx client/src/components/
```

### 2.4 Add Required UI Components

Ensure you have these UI components in your `components/ui/` directory:
- `progress.tsx` (for Progress component)
- All existing Radix UI components (button, card, input, etc.)

If missing, add the Progress component:

```typescript
// components/ui/progress.tsx
import * as React from "react"
import * as ProgressPrimitive from "@radix-ui/react-progress"
import { cn } from "@/lib/utils"

const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root>
>(({ className, value, ...props }, ref) => (
  <ProgressPrimitive.Root
    ref={ref}
    className={cn(
      "relative h-4 w-full overflow-hidden rounded-full bg-secondary",
      className
    )}
    {...props}
  >
    <ProgressPrimitive.Indicator
      className="h-full w-full flex-1 bg-primary transition-all"
      style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
    />
  </ProgressPrimitive.Root>
))
Progress.displayName = ProgressPrimitive.Root.displayName

export { Progress }
```

## Step 3: Configuration and Customization

### 3.1 Environment Variables

Add navigation-specific environment variables to your `.env` file:

```env
# Navigation Assistant Configuration
OPENAI_NAVIGATION_KEY=your_openai_api_key
NAVIGATION_ASSISTANT_ENABLED=true
SMART_SUGGESTIONS_ENABLED=true
ONBOARDING_ENABLED=true
```

### 3.2 Customize App Feature Mapping

Update the `APP_NAVIGATION_MAP` in `navigationOrchestratorService.ts` to match your exact routes and features:

```typescript
const APP_NAVIGATION_MAP = {
  '/dashboard': {
    name: 'Dashboard',
    description: 'Your custom dashboard description',
    keywords: ['dashboard', 'home', 'overview'],
    features: ['your', 'specific', 'features'],
    common_tasks: ['your', 'common', 'tasks']
  },
  // Add all your app's routes
};
```

### 3.3 Customize Tour Definitions

Update the `TOUR_DEFINITIONS` in `GuidedTour.tsx` to match your app's UI elements:

```typescript
const TOUR_DEFINITIONS: Record<string, TourStep[]> = {
  'project-creation': [
    {
      id: 'step-1',
      title: 'Navigate to Projects',
      description: 'Click on your specific projects menu item',
      target: '[data-nav="projects"]', // Update to match your selectors
      position: 'right',
      action: 'click'
    },
    // Customize all steps for your UI
  ]
};
```

### 3.4 Customize Onboarding Flows

Update the `ONBOARDING_FLOWS` in `IntelligentOnboarding.tsx` to match your business logic:

```typescript
const ONBOARDING_FLOWS: OnboardingFlow[] = [
  {
    id: 'beginner-complete',
    name: 'Your Custom Onboarding',
    description: 'Customized for your app',
    steps: [
      // Your custom onboarding steps
    ]
  }
];
```

## Step 4: Testing and Validation

### 4.1 Test Backend Integration

1. Start your development server
2. Test the navigation API endpoints:

```bash
# Test navigation command processing
curl -X POST http://localhost:5000/api/navigation/process-command \
  -H "Content-Type: application/json" \
  -d '{"userId": "test", "currentPath": "/dashboard", "userCommand": "How do I create a project?"}'

# Test suggestions
curl -X POST http://localhost:5000/api/navigation/suggestions \
  -H "Content-Type: application/json" \
  -d '{"userId": "test", "currentPath": "/dashboard"}'
```

### 4.2 Test Frontend Components

1. Navigate to different pages in your app
2. Open the navigation assistant (floating button)
3. Test various queries:
   - "How do I create a project?"
   - "Show me client management"
   - "Help with invoicing"
   - "Take me through time tracking"

### 4.3 Test Guided Tours

1. Trigger tours through the navigation assistant
2. Verify tour steps highlight correct elements
3. Test tour navigation and completion

### 4.4 Test Smart Suggestions

1. Navigate through your app to generate behavior data
2. Check that contextual suggestions appear
3. Verify suggestions are relevant to current page

## Step 5: Production Deployment

### 5.1 Environment Configuration

Set production environment variables:

```env
NODE_ENV=production
OPENAI_API_KEY=your_production_key
NAVIGATION_ASSISTANT_ENABLED=true
```

### 5.2 Database Migrations

Run the database schema updates in production:

```sql
-- Run the ALTER TABLE and CREATE TABLE statements from Step 1.4
```

### 5.3 Performance Optimization

1. **Bundle Size**: Ensure tree shaking is working for unused components
2. **API Rate Limiting**: Implement rate limiting for navigation API endpoints
3. **Caching**: Cache navigation suggestions and tour definitions
4. **Error Handling**: Add comprehensive error boundaries

### 5.4 Monitoring and Analytics

Add tracking for navigation assistant usage:

```typescript
// Track navigation assistant interactions
trackAction({
  type: 'navigation_assistant_usage',
  target: 'query_processed',
  details: { query, response_type, user_satisfaction }
});
```

## Step 6: Advanced Customization

### 6.1 Custom AI Prompts

Customize the system prompts in `navigationOrchestratorService.ts` for your specific domain:

```typescript
function getNavigationSystemPrompt(currentPath: string, currentDate: string): string {
  return `
You are an AI assistant for [YOUR APP NAME], a [YOUR DOMAIN] platform.
Your role is to help users navigate and understand [YOUR SPECIFIC FEATURES].

[YOUR CUSTOM INSTRUCTIONS]
`;
}
```

### 6.2 Custom Suggestion Logic

Extend the suggestion engine with your business-specific logic:

```typescript
// Add to SmartSuggestionEngine.tsx
const generateCustomSuggestions = (analysis: any): SmartSuggestion[] => {
  // Your custom suggestion logic based on your business rules
  return suggestions;
};
```

### 6.3 Integration with Existing Analytics

Connect navigation assistant data with your existing analytics:

```typescript
// In NavigationContext.tsx
const trackAction = useCallback((action) => {
  // Your existing analytics tracking
  yourAnalytics.track('navigation_action', action);
  
  // Navigation assistant tracking
  // ... existing code
}, []);
```

## Troubleshooting

### Common Issues

1. **OpenAI API Errors**
   - Verify API key is set correctly
   - Check rate limits and quotas
   - Ensure model availability (gpt-4o)

2. **Component Not Rendering**
   - Check that NavigationProvider wraps your app
   - Verify all required UI components are available
   - Check console for TypeScript errors

3. **Tours Not Working**
   - Verify CSS selectors match your actual DOM elements
   - Check that target elements are visible when tour starts
   - Update tour definitions for your specific UI

4. **Context Not Updating**
   - Ensure useLocation hook is working correctly
   - Check that API endpoints are returning expected data
   - Verify user ID is being passed correctly

### Debug Mode

Enable debug logging by adding to your environment:

```env
DEBUG_NAVIGATION_ASSISTANT=true
```

Then add debug logs throughout the components:

```typescript
if (process.env.DEBUG_NAVIGATION_ASSISTANT) {
  console.log('Navigation context updated:', context);
}
```

## Support and Maintenance

### Regular Updates

1. **AI Model Updates**: Monitor OpenAI for new model releases
2. **Feature Mapping**: Update navigation maps when adding new features
3. **Tour Maintenance**: Update tours when UI changes
4. **Analytics Review**: Regularly review navigation assistant usage data

### Performance Monitoring

Monitor these metrics:
- Navigation assistant usage rates
- Tour completion rates
- Suggestion click-through rates
- User satisfaction scores
- API response times

## Conclusion

The LLM Navigation Assistant provides a comprehensive solution for helping users navigate your Catch-Up app. The system is designed to be:

- **Extensible**: Easy to add new features and customize behavior
- **Intelligent**: Learns from user behavior and provides contextual help
- **Integrated**: Works seamlessly with your existing AI orchestrator pattern
- **Scalable**: Can handle growing user bases and feature sets

The assistant will help reduce user confusion, improve feature discovery, and enhance overall user experience in your application.

